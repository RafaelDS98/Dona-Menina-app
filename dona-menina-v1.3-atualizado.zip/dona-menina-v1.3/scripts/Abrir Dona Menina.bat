@echo off
title Dona Menina Beauty Bar

echo.
echo  ==========================================
echo   DONA MENINA Beauty Bar - Iniciando...
echo  ==========================================
echo.

taskkill /f /im node.exe >nul 2>&1

:: Detecta raiz automaticamente (este bat esta em raiz\scripts\)
set "SCRIPTS=%~dp0"
set "SCRIPTS=%SCRIPTS:~0,-1%"
for %%i in ("%SCRIPTS%") do set "ROOT=%%~dpi"
set "ROOT=%ROOT:~0,-1%"

echo  [1/2] Iniciando backend...
start "Dona Menina - Backend" /min cmd /c "cd /d "%ROOT%\backend" && npm run dev"

echo  Aguardando backend iniciar...
timeout /t 5 /nobreak >nul

echo  [2/2] Iniciando frontend...
start "Dona Menina - Frontend" /min cmd /c "cd /d "%ROOT%\frontend" && npm run dev"

echo  Aguardando frontend iniciar...
timeout /t 6 /nobreak >nul

echo  Abrindo navegador...
start "" "http://localhost:3000"

echo.
echo  ==========================================
echo   App aberto! Pode minimizar esta janela.
echo   NAO feche as janelas do backend/frontend
echo  ==========================================
echo.
pause
