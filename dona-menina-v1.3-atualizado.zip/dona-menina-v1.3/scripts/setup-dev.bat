@echo off
echo === Dona Menina - Setup do Ambiente ===
echo.
echo Verificando Node.js...
node --version >nul 2>&1
if errorlevel 1 (
    echo Node.js NAO encontrado!
    echo Baixe e instale em: https://nodejs.org/
    echo Escolha a versao LTS e instale com as opcoes padrao.
    pause
    exit /b 1
)
echo Node.js OK!
echo.
echo Instalando dependencias...
cd /d "%~dp0.."
call npm install
cd backend && call npm install && cd ..
cd frontend && call npm install && cd ..
echo.
echo === Setup completo! ===
echo Para rodar em modo dev: scripts\dev.bat
echo Para gerar o .exe: scripts\build.bat
pause
