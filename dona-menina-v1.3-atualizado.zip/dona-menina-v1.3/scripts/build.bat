@echo off
echo === Dona Menina - Gerando Executavel ===
echo.
cd /d "%~dp0.."
echo [1/3] Reconstruindo modulos nativos para Electron...
call npx electron-rebuild -f -w better-sqlite3 -m backend
echo.
echo [2/3] Buildando frontend...
cd frontend && call npm run build && cd ..
echo.
echo [3/3] Empacotando Electron...
call npx electron-builder --win
echo.
echo === Executavel gerado em: release\ ===
echo Procure o arquivo DonaMenina-1.0.0.exe
pause
