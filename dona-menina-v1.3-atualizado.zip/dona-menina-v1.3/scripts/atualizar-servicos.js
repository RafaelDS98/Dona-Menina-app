// Rodar de dentro da pasta backend:
// node atualizar-servicos.js

const Database = require('./node_modules/better-sqlite3');
const path = require('path');

const dbPath = path.join(__dirname, '..', 'data', 'dona_menina.db');
const db = new Database(dbPath);

db.pragma('foreign_keys = ON');
db.pragma('journal_mode = WAL');

const categorias = [
  'Tranças',
  'Unhas',
  'Cabelos',
  'Cílios',
  'Depilação',
  'Maquiagem',
  'Lábios',
  'Sobrancelhas',
];

const servicos = [
  // ── TRANÇAS ──────────────────────────────────────────────
  { categoria: 'Tranças', nome: 'Boho braids (sem material)',        preco: 350 },
  { categoria: 'Tranças', nome: 'Boho braids (com material)',         preco: 450 },
  { categoria: 'Tranças', nome: 'Gypsy braids (sem material)',        preco: 350 },
  { categoria: 'Tranças', nome: 'Gypsy braids (com material)',        preco: 480 },
  { categoria: 'Tranças', nome: 'Goddess braids (sem material)',      preco: 380 },
  { categoria: 'Tranças', nome: 'Goddess braids (com material)',      preco: 500 },
  { categoria: 'Tranças', nome: 'Gypsy com topo nagô (sem material)', preco: 350 },
  { categoria: 'Tranças', nome: 'Gypsy com topo nagô (com material)', preco: 450 },
  { categoria: 'Tranças', nome: 'Entrelace (sem material)',           preco: 250 },
  { categoria: 'Tranças', nome: 'Entrelace (com material)',           preco: 400 },
  { categoria: 'Tranças', nome: 'Alongamento na tela (sem material)', preco: 200 },
  { categoria: 'Tranças', nome: 'Alongamento na tela (com material)', preco: 380 },
  { categoria: 'Tranças', nome: 'Fulani + entrelace (sem material)',  preco: 300 },
  { categoria: 'Tranças', nome: 'Fulani + entrelace (com material)',  preco: 450 },
  { categoria: 'Tranças', nome: 'Fulani + box braids (sem material)', preco: 350 },
  { categoria: 'Tranças', nome: 'Fulani + box braids (com material)', preco: 450 },
  { categoria: 'Tranças', nome: 'Box braids (sem material)',          preco: 400 },
  { categoria: 'Tranças', nome: 'Box braids (com material)',          preco: 480 },
  { categoria: 'Tranças', nome: 'Nagô topo',                         preco: 50  },
  { categoria: 'Tranças', nome: 'Acessórios',                        preco: 5   },

  // ── UNHAS ────────────────────────────────────────────────
  { categoria: 'Unhas', nome: 'Manicure',                                   preco: 35  },
  { categoria: 'Unhas', nome: 'Pedicure',                                   preco: 35  },
  { categoria: 'Unhas', nome: 'Manicure e pedicure',                        preco: 60  },
  { categoria: 'Unhas', nome: 'Postiça tradicional',                        preco: 45  },
  { categoria: 'Unhas', nome: 'Postiça realista',                           preco: 80  },
  { categoria: 'Unhas', nome: 'Soft Gel',                                   preco: 100 },
  { categoria: 'Unhas', nome: 'Banho de gel',                               preco: 100 },
  { categoria: 'Unhas', nome: 'Esmaltação em gel',                          preco: 60  },
  { categoria: 'Unhas', nome: 'Plástica dos pés',                           preco: 80  },
  { categoria: 'Unhas', nome: 'Alongamento molde f1',                       preco: 150 },
  { categoria: 'Unhas', nome: 'Alongamento acrigel',                        preco: 150 },
  { categoria: 'Unhas', nome: 'Alongamento fibra de vidro',                 preco: 180 },
  { categoria: 'Unhas', nome: 'Manutenção molde f1',                        preco: 100 },
  { categoria: 'Unhas', nome: 'Manutenção acrigel',                         preco: 100 },
  { categoria: 'Unhas', nome: 'Manutenção fibra de vidro',                  preco: 130 },
  { categoria: 'Unhas', nome: 'Manutenção banho de gel',                    preco: 80  },
  { categoria: 'Unhas', nome: 'Adicional (francesinha, pedrarias, adesivo)', preco: 5  },
  { categoria: 'Unhas', nome: 'Adicional unhas desenhadas',                 preco: 10  },
  { categoria: 'Unhas', nome: 'Adicional decoração 3D',                     preco: 15  },

  // ── CABELOS ──────────────────────────────────────────────
  { categoria: 'Cabelos', nome: 'Corte',                                  preco: 45  },
  { categoria: 'Cabelos', nome: 'Corte + escova ou finalização',          preco: 80  },
  { categoria: 'Cabelos', nome: 'Hidratação',                             preco: 100 },
  { categoria: 'Cabelos', nome: 'Reconstrução',                           preco: 120 },
  { categoria: 'Cabelos', nome: 'Nutrição',                               preco: 100 },
  { categoria: 'Cabelos', nome: 'Cauterização com queratina',             preco: 120 },
  { categoria: 'Cabelos', nome: 'Coloração total',                        preco: 200 },
  { categoria: 'Cabelos', nome: 'Coloração retoque de raiz (até 4 dedos)', preco: 120 },
  { categoria: 'Cabelos', nome: 'Cronograma capilar (4 sessões)',         preco: 350 },
  { categoria: 'Cabelos', nome: 'Selagem P',                              preco: 150 },
  { categoria: 'Cabelos', nome: 'Selagem M',                              preco: 180 },
  { categoria: 'Cabelos', nome: 'Selagem G',                              preco: 210 },
  { categoria: 'Cabelos', nome: 'Selagem GG',                             preco: 240 },
  { categoria: 'Cabelos', nome: 'Botox P',                                preco: 120 },
  { categoria: 'Cabelos', nome: 'Botox M',                                preco: 150 },
  { categoria: 'Cabelos', nome: 'Botox G',                                preco: 180 },
  { categoria: 'Cabelos', nome: 'Botox GG',                               preco: 210 },
  { categoria: 'Cabelos', nome: 'Escova P',                               preco: 60  },
  { categoria: 'Cabelos', nome: 'Escova M',                               preco: 80  },
  { categoria: 'Cabelos', nome: 'Escova G',                               preco: 100 },
  { categoria: 'Cabelos', nome: 'Escova GG',                              preco: 120 },

  // ── CÍLIOS ───────────────────────────────────────────────
  { categoria: 'Cílios', nome: 'Tufinho fio de seda',                    preco: 50  },
  { categoria: 'Cílios', nome: 'Lash lifting',                           preco: 100 },
  { categoria: 'Cílios', nome: 'Volume express (aplicação)',             preco: 90  },
  { categoria: 'Cílios', nome: 'Volume brasileiro (manutenção)',         preco: 100 },
  { categoria: 'Cílios', nome: 'Volume brasileiro (aplicação)',          preco: 150 },
  { categoria: 'Cílios', nome: 'Volume fox eyes (manutenção)',           preco: 100 },
  { categoria: 'Cílios', nome: 'Volume fox eyes (aplicação)',            preco: 160 },
  { categoria: 'Cílios', nome: 'Volume egípcio (manutenção)',            preco: 100 },
  { categoria: 'Cílios', nome: 'Volume egípcio (aplicação)',             preco: 170 },
  { categoria: 'Cílios', nome: 'Volume Kim Kardashian (manutenção)',     preco: 115 },
  { categoria: 'Cílios', nome: 'Volume Kim Kardashian (aplicação)',      preco: 200 },
  { categoria: 'Cílios', nome: 'Volume luxo (manutenção)',               preco: 105 },
  { categoria: 'Cílios', nome: 'Volume luxo (aplicação)',                preco: 180 },
  { categoria: 'Cílios', nome: 'Volume 30+ (manutenção)',                preco: 115 },
  { categoria: 'Cílios', nome: 'Volume 30+ (aplicação)',                 preco: 200 },
  { categoria: 'Cílios', nome: 'Remoção de cílios',                     preco: 50  },

  // ── DEPILAÇÃO ────────────────────────────────────────────
  { categoria: 'Depilação', nome: 'Depilação - Buço',            preco: 20 },
  { categoria: 'Depilação', nome: 'Depilação - Testa',           preco: 20 },
  { categoria: 'Depilação', nome: 'Depilação - Queixo',          preco: 25 },
  { categoria: 'Depilação', nome: 'Depilação - Rosto',           preco: 60 },
  { categoria: 'Depilação', nome: 'Depilação - Axilas',          preco: 40 },
  { categoria: 'Depilação', nome: 'Depilação - Braço',           preco: 45 },
  { categoria: 'Depilação', nome: 'Depilação - Meia perna',      preco: 60 },
  { categoria: 'Depilação', nome: 'Depilação - Perna completa',  preco: 75 },
  { categoria: 'Depilação', nome: 'Depilação - Virilha',         preco: 40 },
  { categoria: 'Depilação', nome: 'Depilação - Meia pubiana',    preco: 50 },
  { categoria: 'Depilação', nome: 'Depilação - Pubiana completa', preco: 65 },
  { categoria: 'Depilação', nome: 'Depilação - Lateral anal',    preco: 35 },
  { categoria: 'Depilação', nome: 'Clareamento de áreas',        preco: 30 },

  // ── MAQUIAGEM ────────────────────────────────────────────
  { categoria: 'Maquiagem', nome: 'Maquiagem clean sem cílios',         preco: 120 },
  { categoria: 'Maquiagem', nome: 'Maquiagem glam completa a prova d\'água', preco: 150 },
  { categoria: 'Maquiagem', nome: 'Maquiagem artística',                preco: 180 },

  // ── LÁBIOS ───────────────────────────────────────────────
  { categoria: 'Lábios', nome: 'Hydra gloss (hidratação labial profunda)', preco: 80  },
  { categoria: 'Lábios', nome: 'Micropigmentação labial',                  preco: 350 },

  // ── SOBRANCELHAS ─────────────────────────────────────────
  { categoria: 'Sobrancelhas', nome: 'Design ou limpeza de sobrancelha', preco: 35  },
  { categoria: 'Sobrancelhas', nome: 'Design com henna',                 preco: 55  },
  { categoria: 'Sobrancelhas', nome: 'Brow Lamination',                  preco: 100 },
  { categoria: 'Sobrancelhas', nome: 'Micropigmentação de sobrancelha',  preco: 300 },
];

const atualizar = db.transaction(() => {
  db.prepare('UPDATE servicos SET ativo = 0').run();
  console.log('Servicos antigos desativados');

  db.prepare('DELETE FROM servico_categorias').run();
  console.log('Categorias antigas removidas');

  const insertCat = db.prepare('INSERT INTO servico_categorias (nome) VALUES (?)');
  const catMap = {};
  for (const nome of categorias) {
    const result = insertCat.run(nome);
    catMap[nome] = result.lastInsertRowid;
  }
  console.log(categorias.length + ' categorias inseridas');

  const insertSvc = db.prepare('INSERT INTO servicos (nome, categoria_id, preco, ativo) VALUES (?, ?, ?, 1)');
  for (const s of servicos) {
    insertSvc.run(s.nome, catMap[s.categoria], s.preco);
  }
  console.log(servicos.length + ' servicos inseridos');
});

try {
  atualizar();
  console.log('\nCatalogo atualizado com sucesso!');
  console.log('Reinicie o backend para ver as alteracoes.');
} catch (err) {
  console.error('\n❌ Erro ao atualizar:', err.message);
} finally {
  db.close();
}
