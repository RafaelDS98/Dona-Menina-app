@echo off
echo === Dona Menina - Modo Desenvolvimento ===
echo.
echo Backend em http://localhost:4000
echo Frontend em http://localhost:5173
echo.
start "Backend" cmd /k "cd /d %~dp0..\backend && npm run dev"
timeout /t 2 >nul
start "Frontend" cmd /k "cd /d %~dp0..\frontend && npm run dev"
echo.
echo Duas janelas abertas: Backend e Frontend
echo Feche ambas para parar.
pause
