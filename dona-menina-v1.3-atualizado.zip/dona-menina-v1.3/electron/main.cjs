const { app, BrowserWindow } = require('electron');
const path = require('path');
const fs = require('fs');

let mainWindow = null;

function getDataPath() {
  if (app.isPackaged) {
    // Produção: pasta data/ ao lado do .exe
    return path.join(path.dirname(process.execPath), 'data');
  }
  // Dev: pasta data/ na raiz do projeto
  return path.join(__dirname, '..', 'data');
}

function getSchemaPath(filename) {
  if (app.isPackaged) {
    return path.join(process.resourcesPath, filename);
  }
  return path.join(__dirname, '..', 'backend', 'database', filename);
}

async function startBackend() {
  const dataPath = getDataPath();

  // Cria pasta data/ se nao existir
  if (!fs.existsSync(dataPath)) {
    fs.mkdirSync(dataPath, { recursive: true });
  }

  // Configura env vars para o backend
  process.env.DB_PATH = path.join(dataPath, 'dona_menina.db');
  process.env.PORT = '4000';
  process.env.SCHEMA_PATH = getSchemaPath('schema.sql');
  process.env.SEED_PATH = getSchemaPath('seed.sql');

  // Frontend buildado servido como arquivos estaticos
  if (app.isPackaged) {
    process.env.STATIC_DIR = path.join(process.resourcesPath, '..', 'frontend', 'dist');
  } else {
    const devDistPath = path.join(__dirname, '..', 'frontend', 'dist');
    if (fs.existsSync(devDistPath)) {
      process.env.STATIC_DIR = devDistPath;
    }
  }

  // Importa o backend (ES module via dynamic import)
  const backendPath = app.isPackaged
    ? path.join(process.resourcesPath, '..', 'backend', 'server.js')
    : path.join(__dirname, '..', 'backend', 'server.js');

  await import(`file://${backendPath}`);
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 800,
    minWidth: 1024,
    minHeight: 600,
    title: 'Dona Menina Beauty Bar',
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.loadURL('http://localhost:4000');

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(async () => {
  try {
    await startBackend();
    // Pequeno delay para o Express ficar pronto
    await new Promise((resolve) => setTimeout(resolve, 500));
    createWindow();
  } catch (err) {
    console.error('Erro ao iniciar o backend:', err);
    app.quit();
  }
});

app.on('window-all-closed', () => {
  app.quit();
});

app.on('activate', () => {
  if (mainWindow === null) {
    createWindow();
  }
});
